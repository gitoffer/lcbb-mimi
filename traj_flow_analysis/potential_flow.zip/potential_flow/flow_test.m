

for i = 1:10
    
    [W0,x,y] = uniform_flow(.1*i,pi/4,-10:1:10);
    W1 = swirl(1,5,-10:1:10);
    W2 = sink(1,5,-10:1:10);
    W3 = source(1,1-5i,-10:1:10);
    W4 = doublet(10,0);
    
    W = W0 + W1;
    [Vx,Vy] = velocity_from_potential(W);
    figure(1)
    quiver(Vx,Vy,0)
    figure(2)
    pcolor(x,y,imag(W))
    
    V = cat(3,Vx,Vy);
    V = grid2list(flat(V(:,:,1)),flat(V(:,:,2)));
    centroids = grid2list(x(:),y(:));
    [Cvv(i,:),R] = spatial_correlation_function(V,centroids,30);
    
end

figure
mesh(Cvv)