function [W,varargout] = uniform_flow(mag,dir,x)

if ~exist('x','var'), x= -10:.5:10; end
[x,y] = meshgrid(x);

z = x + y*1i;

W = mag*exp(-1i*dir).*z;


if nargout > 1
    varargout{1} = x;
    varargout{2} = y;
end