function [W,varargout] = swirl(gamma,zA,x)

if ~exist('x','var'), x= -10:.5:10; end
[x,y] = meshgrid(x);

z = x + y*1i;
W = 1i*gamma*(2*pi)*log(z-zA);

if nargout > 1
    varargout{1} = Xf;
    varargout{2} = Yf;
end