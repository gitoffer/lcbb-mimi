function A = get_ellipse_area(a,b)

A = pi*a*b;