function i = argmax(f)
[bla,i] = max(f);
end
